export {}

declare global {
  interface Window {
    lexentia: {
      workspace: {
        openFolder: () => Promise<{ ok: boolean; workspaceRoot?: string }>
        get: () => Promise<{ ok: boolean; workspaceRoot: string | null }>
      }
      fs: {
        listDir: (
          relPath: string,
        ) => Promise<{
          ok: boolean
          entries?: { name: string; isDir: boolean; size: number; mtimeMs: number }[]
        }>
        readFile: (relPath: string) => Promise<{ ok: boolean; content?: string }>
        writeFile: (relPath: string, content: string) => Promise<{ ok: boolean }>
      }
      terminal: {
        create: (opts?: { cwd?: string | null }) => Promise<{ ok: boolean; id?: string }>
        write: (id: string, data: string) => Promise<{ ok: boolean }>
        resize: (id: string, cols: number, rows: number) => Promise<{ ok: boolean }>
        kill: (id: string) => Promise<{ ok: boolean }>
        onData: (cb: (payload: { id: string; data: string }) => void) => () => void
      }
      window: {
        minimize: () => Promise<{ ok: boolean }>
        toggleMaximize: () => Promise<{ ok: boolean; isMaximized: boolean }>
        close: () => Promise<{ ok: boolean }>
        isMaximized: () => Promise<{ ok: boolean; isMaximized: boolean }>
      }
    }
  }
}

