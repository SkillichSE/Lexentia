export type PersistedChatRole = 'user' | 'assistant'

export type PersistedMessage = {
  id: string
  role: PersistedChatRole
  content: string
  createdAt: number
}

export type HistorySession = {
  id: string
  createdAt: number
  updatedAt: number
  modelName?: string
  messages: PersistedMessage[]
}

export type HistoryStore = {
  version: 1
  sessions: HistorySession[]
}

const STORAGE_KEY = 'lexentia.history.v1'

function safeParseJson(input: string): any | null {
  try {
    return JSON.parse(input)
  } catch {
    return null
  }
}

function now() {
  return Date.now()
}

function makeId(prefix: string) {
  return `${prefix}-${now()}-${Math.random().toString(16).slice(2)}`
}

export class HistoryService {
  private loadStore(): HistoryStore {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return { version: 1, sessions: [] }
    const parsed = safeParseJson(raw)
    if (!parsed || parsed.version !== 1 || !Array.isArray(parsed.sessions)) return { version: 1, sessions: [] }
    return parsed as HistoryStore
  }

  private saveStore(store: HistoryStore) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(store))
  }

  createSession(modelName?: string): HistorySession {
    const store = this.loadStore()
    const session: HistorySession = {
      id: makeId('session'),
      createdAt: now(),
      updatedAt: now(),
      modelName,
      messages: [],
    }
    store.sessions.unshift(session)
    this.saveStore(store)
    return session
  }

  getSession(sessionId: string): HistorySession | null {
    const store = this.loadStore()
    return store.sessions.find((s) => s.id === sessionId) ?? null
  }

  addMessage(sessionId: string, msg: PersistedMessage, modelName?: string) {
    const store = this.loadStore()
    const idx = store.sessions.findIndex((s) => s.id === sessionId)
    if (idx === -1) return
    const session = store.sessions[idx]
    session.modelName = modelName ?? session.modelName
    session.messages.push(msg)
    session.updatedAt = now()
    this.saveStore(store)
  }

  exportSession(sessionId: string): string {
    const session = this.getSession(sessionId)
    if (!session) throw new Error('Session not found')
    return JSON.stringify(session, null, 2)
  }

  clearAll() {
    localStorage.removeItem(STORAGE_KEY)
  }
}

export function downloadText(filename: string, text: string, mime = 'application/json') {
  const blob = new Blob([text], { type: mime })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  a.click()
  URL.revokeObjectURL(url)
}

