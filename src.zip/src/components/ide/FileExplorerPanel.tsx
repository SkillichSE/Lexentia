import { useEffect, useMemo, useState } from 'react'

type DirEntry = { name: string; isDir: boolean; size: number; mtimeMs: number }

type TreeNode = {
  id: string
  name: string
  relPath: string
  isDir: boolean
  expanded?: boolean
  loading?: boolean
  children?: TreeNode[]
}

function joinRel(base: string, name: string) {
  if (!base || base === '.') return name
  return `${base}/${name}`
}

function toNode(entry: DirEntry, parentRel: string): TreeNode {
  const relPath = joinRel(parentRel, entry.name)
  return { id: relPath, name: entry.name, relPath, isDir: entry.isDir }
}

export function FileExplorerPanel({
  onOpenFile,
  onWorkspaceChanged,
}: {
  onOpenFile: (relPath: string) => void
  onWorkspaceChanged?: (workspaceRoot: string | null) => void
}) {
  const [workspaceRoot, setWorkspaceRoot] = useState<string | null>(null)
  const [root, setRoot] = useState<TreeNode | null>(null)

  useEffect(() => {
    ;(async () => {
      const res = await window.lexentia.workspace.get()
      const ws = res.workspaceRoot
      setWorkspaceRoot(ws)
      onWorkspaceChanged?.(ws)
      if (ws) {
        setRoot({
          id: '.',
          name: ws.split(/[\\/]/).pop() || ws,
          relPath: '.',
          isDir: true,
          expanded: true,
          loading: true,
        })
      } else {
        setRoot(null)
      }
    })()
  }, [onWorkspaceChanged])

  useEffect(() => {
    if (!root || !root.expanded) return
    if (root.children && root.children.length) return
    ;(async () => {
      try {
        const res = await window.lexentia.fs.listDir('.')
        const entries = res.entries ?? []
        setRoot((prev) =>
          prev
            ? {
                ...prev,
                loading: false,
                children: entries.map((e) => toNode(e, '.')),
              }
            : prev,
        )
      } catch {
        setRoot((prev) => (prev ? { ...prev, loading: false } : prev))
      }
    })()
  }, [root])

  const openFolder = async () => {
    const res = await window.lexentia.workspace.openFolder()
    if (!res.ok || !res.workspaceRoot) return
    const ws = res.workspaceRoot
    setWorkspaceRoot(ws)
    onWorkspaceChanged?.(ws)
    setRoot({
      id: '.',
      name: ws.split(/[\\/]/).pop() || ws,
      relPath: '.',
      isDir: true,
      expanded: true,
      loading: true,
    })
  }

  const workspaceLabel = useMemo(() => workspaceRoot ?? 'No workspace', [workspaceRoot])

  const toggleDir = async (node: TreeNode) => {
    if (!node.isDir) return
    const willExpand = !node.expanded
    if (!willExpand) {
      setRoot((prev) => (prev ? patchNode(prev, node.relPath, (n) => ({ ...n, expanded: false })) : prev))
      return
    }

    setRoot((prev) =>
      prev
        ? patchNode(prev, node.relPath, (n) => ({
            ...n,
            expanded: true,
            loading: !n.children,
          }))
        : prev,
    )

    // lazy load
    if (node.children) return
    const res = await window.lexentia.fs.listDir(node.relPath)
    const entries = res.entries ?? []
    setRoot((prev) =>
      prev
        ? patchNode(prev, node.relPath, (n) => ({
            ...n,
            loading: false,
            children: entries.map((e) => toNode(e, node.relPath)),
          }))
        : prev,
    )
  }

  return (
    <div className="lex-explorer">
      <div className="lex-explorerHeader">
        <div className="lex-sectionTitle">Explorer</div>
        <button className="lex-btn lex-btn--primary" onClick={openFolder}>
          Open folder
        </button>
      </div>
      <div className="lex-subtle" style={{ marginBottom: 10 }}>
        {workspaceLabel}
      </div>

      <div className="lex-tree" role="tree" aria-label="File tree">
        {!root ? (
          <div className="lex-empty">Open a project folder.</div>
        ) : (
          <TreeNodeView node={root} depth={0} onToggle={toggleDir} onOpenFile={onOpenFile} />
        )}
      </div>
    </div>
  )
}

function TreeNodeView({
  node,
  depth,
  onToggle,
  onOpenFile,
}: {
  node: TreeNode
  depth: number
  onToggle: (node: TreeNode) => void
  onOpenFile: (relPath: string) => void
}) {
  const indent = 10 + depth * 12
  return (
    <div>
      <div
        className={node.isDir ? 'lex-treeRow lex-treeRow--dir' : 'lex-treeRow'}
        style={{ paddingLeft: indent }}
        onClick={() => (node.isDir ? onToggle(node) : onOpenFile(node.relPath))}
        role="treeitem"
        aria-expanded={node.isDir ? !!node.expanded : undefined}
      >
        <span className="lex-treeIcon">{node.isDir ? (node.expanded ? '▾' : '▸') : '•'}</span>
        <span className="lex-treeName">{node.name}</span>
        {node.loading ? <span className="lex-treeMeta">loading…</span> : null}
      </div>
      {node.isDir && node.expanded && node.children ? (
        <div role="group">
          {node.children.map((c) => (
            <TreeNodeView key={c.id} node={c} depth={depth + 1} onToggle={onToggle} onOpenFile={onOpenFile} />
          ))}
        </div>
      ) : null}
    </div>
  )
}

function patchNode(root: TreeNode, relPath: string, fn: (n: TreeNode) => TreeNode): TreeNode {
  if (root.relPath === relPath) return fn(root)
  if (!root.children) return root
  return {
    ...root,
    children: root.children.map((c) => patchNode(c, relPath, fn)),
  }
}

