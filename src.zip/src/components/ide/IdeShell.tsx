import { useEffect, useMemo, useRef, useState } from 'react'
import { ChatPanel, type ChatMessage } from './ChatPanel'
import { EditorPanel } from './EditorPanel'
import { LogsPanel } from './LogsPanel'
import { ModelService } from '../../services/modelService'
import { ToolsClient } from '../../tools/ToolsClient'
import { downloadText, HistoryService } from '../../services/historyService'
import { FileExplorerPanel } from './FileExplorerPanel'
import { TerminalPanel } from './TerminalPanel'
import { loadProfiles, saveProfiles, setActiveProfile, upsertProfile, type ModelProfile } from '../../services/modelProfiles'
import { ActivityBar } from './ActivityBar'
import { SettingsView } from './SettingsView'
import { OnboardingOverlay } from './OnboardingOverlay'
import { FilesPanel } from './FilesPanel'
import { loadSettings, saveSettings } from '../../services/settingsService'
import { loadWorkbenchState, saveWorkbenchState, type ActivityView, type BottomTab, type MainView } from '../../state/workbenchState'

export function IdeShell() {
  const [workbench, setWorkbench] = useState(() => loadWorkbenchState())
  const [settings, setSettings] = useState(() => loadSettings())
  const [profilesState, setProfilesState] = useState(() => loadProfiles())
  const activeProfile = profilesState.profiles.find((p) => p.id === profilesState.activeProfileId) as ModelProfile
  const [connectedProfileId, setConnectedProfileId] = useState<string | null>(null)
  const modelService = useMemo(() => new ModelService(), [])
  const toolsClient = useMemo(() => new ToolsClient(settings.toolsBaseUrl), [settings.toolsBaseUrl])
  const historyService = useMemo(() => new HistoryService(), [])
  const [messages, setMessages] = useState<ChatMessage[]>(() => [{ id: `m-${Date.now()}-assistant`, role: 'assistant', content: 'Welcome! Connect a model in Settings and describe your task.', createdAt: Date.now() }])
  const [logs, setLogs] = useState<string[]>(['Lexentia: workbench started'])
  const [workspaceRoot, setWorkspaceRoot] = useState<string | null>(null)
  const [extractedText, setExtractedText] = useState<string | null>(null)
  const [session] = useState(() => historyService.createSession(undefined))
  const [clarification, setClarification] = useState<{ question: string; options: string[] } | null>(null)
  const [tabs, setTabs] = useState<{ relPath: string; name: string; content: string; isDirty: boolean }[]>([])
  const [activeRelPath, setActiveRelPath] = useState<string | null>(null)
  const [isMaximized, setIsMaximized] = useState(false)
  const chatInputRef = useRef<HTMLTextAreaElement | null>(null)

  useEffect(() => {
    ;(async () => {
      const res = await window.lexentia.window.isMaximized()
      if (res.ok) setIsMaximized(res.isMaximized)
    })()
  }, [])

  useEffect(() => {
    saveWorkbenchState(workbench)
  }, [workbench])

  useEffect(() => {
    saveSettings(settings)
  }, [settings])

  const statusLine = useMemo(() => {
    if (!connectedProfileId) return 'Model not connected'
    const p = profilesState.profiles.find((x) => x.id === connectedProfileId)
    return p ? `Model: ${p.name}` : 'Model not connected'
  }, [connectedProfileId, profilesState.profiles])

  const addLog = (line: string) => {
    setLogs((prev) => {
      const next = [...prev, line]
      return next.length > 500 ? next.slice(next.length - 500) : next
    })
  }

  const onConnectModel = () => {
    setConnectedProfileId(activeProfile.id)
    addLog(`Model profile: ${activeProfile.name}`)
  }

  const exportHistory = () => {
    const json = historyService.exportSession(session.id)
    downloadText(`lexentia-history-${session.id}.json`, json, 'application/json')
    addLog('History exported.')
  }

  const clearHistory = () => {
    historyService.clearAll()
    addLog('History cleared.')
    window.location.reload()
  }

  const applyExtractedContext = (baseText: string) => (extractedText ? `${baseText}\n\n[EXTRACTED_FILES_TEXT]\n${extractedText}`.trim() : baseText)

  const updateActivityView = (view: ActivityView) => {
    setWorkbench((prev) => ({ ...prev, activityView: view, mainView: view === 'chat' ? 'chat' : prev.mainView }))
  }
  const updateMainView = (view: MainView) => setWorkbench((prev) => ({ ...prev, mainView: view }))
  const updateBottomTab = (tab: BottomTab) => setWorkbench((prev) => ({ ...prev, bottomVisible: true, bottomTab: tab }))

  const openFile = async (relPath: string) => {
    const already = tabs.find((t) => t.relPath === relPath)
    if (already) {
      setActiveRelPath(relPath)
      updateMainView('editor')
      return
    }
    const res = await window.lexentia.fs.readFile(relPath)
    if (!res.ok) return addLog(`Failed to open file: ${relPath}`)
    setTabs((prev) => [...prev, { relPath, name: relPath.split('/').pop() || relPath, content: res.content ?? '', isDirty: false }])
    setActiveRelPath(relPath)
    setWorkbench((prev) => ({ ...prev, activityView: 'explorer', mainView: 'editor' }))
    addLog(`Opened: ${relPath}`)
  }

  const saveActive = async () => {
    const rel = activeRelPath
    if (!rel) return
    const tab = tabs.find((t) => t.relPath === rel)
    if (!tab) return
    await window.lexentia.fs.writeFile(rel, tab.content)
    setTabs((prev) => prev.map((t) => (t.relPath === rel ? { ...t, isDirty: false } : t)))
    addLog(`Saved: ${rel}`)
  }

  const closeTab = (relPath: string) => {
    setTabs((prev) => prev.filter((t) => t.relPath !== relPath))
    setActiveRelPath((prev) => {
      if (prev !== relPath) return prev
      const remaining = tabs.filter((t) => t.relPath !== relPath)
      return remaining.length ? remaining[remaining.length - 1].relPath : null
    })
  }

  const onClarificationSelect = (option: string) => {
    if (!connectedProfileId) return setClarification(null)
    const now = Date.now()
    setClarification(null)
    const userMsg: ChatMessage = { id: `m-${now}-user`, role: 'user', content: option, createdAt: now }
    const assistantId = `m-${now}-assistant`
    setMessages((prev) => [...prev, userMsg, { id: assistantId, role: 'assistant', content: 'Thinking…', createdAt: now + 1 }])
    historyService.addMessage(session.id, userMsg, activeProfile.model)
    ;(async () => {
      try {
        const history = messages.map((m) => ({ role: m.role, content: m.content }))
        const result = await modelService.next([...history, { role: 'user', content: applyExtractedContext(option) }], activeProfile, { temperature: settings.temperature, topP: settings.topP })
        if (result.type === 'clarify') {
          const clarifyContent = `Clarification: ${result.question}\n\nOptions:\n- ${result.options.join('\n- ')}`
          setClarification({ question: result.question, options: result.options })
          setMessages((prev) => prev.map((m) => (m.id === assistantId ? { ...m, content: clarifyContent } : m)))
          historyService.addMessage(session.id, { id: assistantId, role: 'assistant', content: clarifyContent, createdAt: now + 1 }, activeProfile.model)
          return
        }
        setMessages((prev) => prev.map((m) => (m.id === assistantId ? { ...m, content: result.content } : m)))
        historyService.addMessage(session.id, { id: assistantId, role: 'assistant', content: result.content, createdAt: now + 1 }, activeProfile.model)
      } catch (e: any) {
        const msg = e?.message ? String(e.message) : 'Unknown error'
        setMessages((prev) => prev.map((m) => (m.id === assistantId ? { ...m, content: `Model request failed: ${msg}` } : m)))
      }
    })()
  }

  const onSendChat = (text: string) => {
    const trimmed = text.trim()
    if (!trimmed) return
    const now = Date.now()
    const userMsg: ChatMessage = { id: `m-${now}-user`, role: 'user', content: trimmed, createdAt: now }
    const assistantId = `m-${now}-assistant`
    setMessages((prev) => [...prev, userMsg, { id: assistantId, role: 'assistant', content: 'Thinking…', createdAt: now + 1 }])
    historyService.addMessage(session.id, userMsg, activeProfile.model)
    ;(async () => {
      if (!connectedProfileId) {
        setMessages((prev) => prev.map((m) => (m.id === assistantId ? { ...m, content: 'Connect a model first in Settings (Connect).' } : m)))
        return
      }
      try {
        const filesToExtract: File[] = []
        if (filesToExtract.length) {
          const parts: string[] = []
          for (const f of filesToExtract) {
            const res = await toolsClient.extractByExtension(f)
            parts.push(`FILE: ${f.name}\n-----\n${res.text}`)
          }
          const combined = parts.join('\n\n')
          setExtractedText(combined)
          const history = messages.map((m) => ({ role: m.role, content: m.content }))
          const result = await modelService.next([...history, { role: 'user', content: `${trimmed}\n\n[EXTRACTED_FILES_TEXT]\n${combined}`.trim() }], activeProfile, { temperature: settings.temperature, topP: settings.topP })
          if (result.type === 'clarify') {
            const clarifyContent = `Clarification: ${result.question}\n\nOptions:\n- ${result.options.join('\n- ')}`
            setClarification({ question: result.question, options: result.options })
            setMessages((prev) => prev.map((m) => (m.id === assistantId ? { ...m, content: clarifyContent } : m)))
            return
          }
          setMessages((prev) => prev.map((m) => (m.id === assistantId ? { ...m, content: result.content } : m)))
          return
        }

        const history = messages.map((m) => ({ role: m.role, content: m.content }))
        const result = await modelService.next([...history, { role: 'user', content: trimmed }], activeProfile, { temperature: settings.temperature, topP: settings.topP })
        if (result.type === 'clarify') {
          const clarifyContent = `Clarification: ${result.question}\n\nOptions:\n- ${result.options.join('\n- ')}`
          setClarification({ question: result.question, options: result.options })
          setMessages((prev) => prev.map((m) => (m.id === assistantId ? { ...m, content: clarifyContent } : m)))
          historyService.addMessage(session.id, { id: assistantId, role: 'assistant', content: clarifyContent, createdAt: now + 1 }, activeProfile.model)
          return
        }
        setClarification(null)
        setMessages((prev) => prev.map((m) => (m.id === assistantId ? { ...m, content: result.content } : m)))
        historyService.addMessage(session.id, { id: assistantId, role: 'assistant', content: result.content, createdAt: now + 1 }, activeProfile.model)
      } catch (e: any) {
        const msg = e?.message ? String(e.message) : 'Unknown error'
        setMessages((prev) => prev.map((m) => (m.id === assistantId ? { ...m, content: `Model request failed: ${msg}` } : m)))
      }
    })()
  }

  const hasSentMessage = messages.some((m) => m.role === 'user')
  const activeFile = activeRelPath ? tabs.find((t) => t.relPath === activeRelPath) ?? null : null

  return (
    <div className="lex-root">
      <div className="lex-topbar">
        <div className="lex-brand">Lexentia</div>
        <div className="lex-status">{statusLine}</div>
        <div className="lex-windowControls">
          <button className="lex-windowBtn" onClick={() => window.lexentia.window.minimize()} title="Minimize">&#8211;</button>
          <button className="lex-windowBtn" onClick={async () => { const res = await window.lexentia.window.toggleMaximize(); if (res.ok) setIsMaximized(res.isMaximized) }} title="Maximize">{isMaximized ? '❐' : '□'}</button>
          <button className="lex-windowBtn lex-windowBtn--close" onClick={() => window.lexentia.window.close()} title="Close">×</button>
        </div>
      </div>

      <div className="lex-workbench">
        <ActivityBar active={workbench.activityView} onSelect={updateActivityView} />
        <aside className="lex-sidebar">
          {workbench.activityView === 'explorer' ? <FileExplorerPanel onOpenFile={openFile} onWorkspaceChanged={setWorkspaceRoot} /> : null}
          {workbench.activityView === 'chat' ? <div className="lex-sideSection"><div className="lex-sectionTitle">Chat Tools</div><FilesPanel onChange={() => addLog('Files staged.')} /></div> : null}
          {workbench.activityView === 'history' ? <div className="lex-sideSection"><div className="lex-sectionTitle">Session</div><div className="lex-subtle">{session.id}</div><div className="lex-field lex-field--row"><button className="lex-btn lex-btn--primary" onClick={exportHistory}>Export</button><button className="lex-btn" onClick={clearHistory}>Clear</button></div></div> : null}
          {workbench.activityView === 'settings' ? (
            <SettingsView
              profilesState={profilesState}
              activeProfile={activeProfile}
              onActiveProfileIdChange={(id) => { const next = setActiveProfile(profilesState, id); setProfilesState(next); saveProfiles(next) }}
              onModelNameChange={(v) => { const next = upsertProfile(profilesState, { ...activeProfile, model: v }); setProfilesState(next); saveProfiles(next) }}
              onBaseUrlChange={(v) => { const next = upsertProfile(profilesState, { ...activeProfile, baseUrl: v }); setProfilesState(next); saveProfiles(next) }}
              onApiKeyChange={activeProfile.provider === 'openai_compatible' ? (v) => { const next = upsertProfile(profilesState, { ...activeProfile, apiKey: v || undefined }); setProfilesState(next); saveProfiles(next) } : undefined}
              onConnectModel={onConnectModel}
              toolsBaseUrl={settings.toolsBaseUrl}
              onToolsBaseUrlChange={(v) => setSettings((p) => ({ ...p, toolsBaseUrl: v }))}
              temperature={settings.temperature}
              onTemperatureChange={(v) => setSettings((p) => ({ ...p, temperature: v }))}
              topP={settings.topP}
              onTopPChange={(v) => setSettings((p) => ({ ...p, topP: v }))}
              onExportHistory={exportHistory}
              onClearHistory={clearHistory}
            />
          ) : null}
        </aside>

        <main className="lex-main">
          {workbench.mainView === 'chat' ? (
            <ChatPanel messages={messages} onSend={onSendChat} inputRef={chatInputRef} clarification={clarification} onClarificationSelect={onClarificationSelect} />
          ) : (
            <div className="lex-editorHost">
              <div className="lex-editorTabs">
                {tabs.length === 0 ? <div className="lex-subtle">No files open</div> : tabs.map((t) => (
                  <div key={t.relPath} className={t.relPath === activeRelPath ? 'lex-tab lex-tab--active' : 'lex-tab'} onClick={() => setActiveRelPath(t.relPath)}>
                    <span>{t.name}{t.isDirty ? '•' : ''}</span>
                    <button className="lex-btn" onClick={(e) => { e.stopPropagation(); closeTab(t.relPath) }}>×</button>
                  </div>
                ))}
                {activeRelPath ? <button className="lex-btn lex-btn--primary" onClick={saveActive}>Save</button> : null}
                <button className="lex-btn" onClick={() => updateMainView('chat')}>Open Chat</button>
              </div>
              <EditorPanel
                extractedText={extractedText}
                activeFile={activeFile}
                onChange={(content) => {
                  const rel = activeRelPath
                  if (!rel) return
                  setTabs((prev) => prev.map((t) => (t.relPath === rel ? { ...t, content, isDirty: true } : t)))
                }}
                onSave={saveActive}
              />
            </div>
          )}
        </main>

        <aside className={workbench.secondaryVisible ? 'lex-secondary' : 'lex-secondary lex-secondary--hidden'}>
          <div className="lex-sectionTitle">Context</div>
          <div className="lex-subtle">Workspace: {workspaceRoot ?? 'Not opened'}</div>
          <div className="lex-subtle">Open files: {tabs.length}</div>
          <div className="lex-field lex-field--row">
            <button className="lex-btn" onClick={() => setWorkbench((p) => ({ ...p, secondaryVisible: !p.secondaryVisible }))}>{workbench.secondaryVisible ? 'Hide panel' : 'Show panel'}</button>
            <button className="lex-btn" onClick={() => updateActivityView('settings')}>Settings</button>
          </div>
        </aside>

        <section className={workbench.bottomVisible ? 'lex-bottomPanel' : 'lex-bottomPanel lex-bottomPanel--hidden'}>
          <div className="lex-bottomHeader">
            <div className="lex-modeSwitch lex-modeSwitch--two">
              <button className={workbench.bottomTab === 'terminal' ? 'lex-modeBtn lex-modeBtn--active' : 'lex-modeBtn'} onClick={() => updateBottomTab('terminal')}>Terminal</button>
              <button className={workbench.bottomTab === 'logs' ? 'lex-modeBtn lex-modeBtn--active' : 'lex-modeBtn'} onClick={() => updateBottomTab('logs')}>Logs</button>
            </div>
            <button className="lex-btn" onClick={() => setWorkbench((p) => ({ ...p, bottomVisible: !p.bottomVisible }))}>Collapse</button>
          </div>
          <div className="lex-bottomBody">{workbench.bottomTab === 'terminal' ? <TerminalPanel cwd={workspaceRoot} /> : <LogsPanel lines={logs} onClear={() => setLogs([])} />}</div>
        </section>
      </div>

      <OnboardingOverlay
        open={!settings.onboardingCompleted}
        hasConnectedModel={Boolean(connectedProfileId)}
        hasWorkspace={Boolean(workspaceRoot)}
        hasSentMessage={hasSentMessage}
        onGoSettings={() => updateActivityView('settings')}
        onGoExplorer={() => updateActivityView('explorer')}
        onGoChat={() => setWorkbench((prev) => ({ ...prev, activityView: 'chat', mainView: 'chat' }))}
        onComplete={() => setSettings((prev) => ({ ...prev, onboardingCompleted: true }))}
      />
    </div>
  )
}

