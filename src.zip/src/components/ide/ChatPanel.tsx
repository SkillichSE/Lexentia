import { useEffect, useMemo, useRef, useState } from 'react'
import { ClarificationMenu } from '../ClarificationMenu'

export type ChatRole = 'user' | 'assistant'

export type ChatMessage = {
  id: string
  role: ChatRole
  content: string
  createdAt: number
}

export function ChatPanel({
  messages,
  onSend,
  inputRef,
  clarification,
  onClarificationSelect,
}: {
  messages: ChatMessage[]
  onSend: (text: string) => void
  inputRef?: React.RefObject<HTMLTextAreaElement | null>
  clarification?: { question: string; options: string[] } | null
  onClarificationSelect?: (opt: string) => void
}) {
  const [draft, setDraft] = useState('')
  const listRef = useRef<HTMLDivElement | null>(null)

  useEffect(() => {
    const el = listRef.current
    if (!el) return
    el.scrollTop = el.scrollHeight
  }, [messages.length])

  const placeholder = useMemo(
    () => 'Опиши задачу... (Ctrl/⌘ + Enter для отправки)',
    [],
  )

  const send = () => {
    const text = draft.trim()
    if (!text) return
    onSend(text)
    setDraft('')
  }

  // Input is only blocked while we're actively waiting for a clarification answer.
  // Once the clarification menu is shown, the user should interact with it — not type.
  const inputBlocked = !!clarification

  return (
    <div className="lex-chatPanel">
      <div className="lex-chatList" ref={listRef}>
        {messages.map((m) => (
          <div
            key={m.id}
            className={m.role === 'user' ? 'lex-msg lex-msg--user' : 'lex-msg lex-msg--assistant'}
          >
            <div className="lex-msgRole">{m.role === 'user' ? 'You' : 'Lexentia'}</div>
            {/* FIX: render newlines properly so code and multi-line answers display correctly */}
            <div className="lex-msgContent">
              {m.content.split('\n').map((line, i, arr) => (
                <span key={i}>
                  {line}
                  {i < arr.length - 1 && <br />}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* FIX: clarification menu always renders when clarification is set,
          independently of whether JSON parse succeeded — guard moved here */}
      {clarification && Array.isArray(clarification.options) && clarification.options.length >= 2 ? (
        <ClarificationMenu
          question={clarification.question}
          options={clarification.options}
          onSelect={(opt) => onClarificationSelect?.(opt)}
        />
      ) : null}

      <div className="lex-chatComposer">
        <textarea
          ref={inputRef}
          className="lex-chatInput"
          value={draft}
          placeholder={placeholder}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            if (inputBlocked) return
            if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
              e.preventDefault()
              send()
            }
          }}
          disabled={inputBlocked}
        />
        <div className="lex-chatActions">
          <button className="lex-btn lex-btn--primary" onClick={send} disabled={inputBlocked}>
            Send
          </button>
          <div className="lex-hint">Ctrl/⌘ + Enter</div>
        </div>
      </div>
    </div>
  )
}