export function OnboardingOverlay({
  open,
  hasConnectedModel,
  hasWorkspace,
  hasSentMessage,
  onGoSettings,
  onGoExplorer,
  onGoChat,
  onComplete,
}: {
  open: boolean
  hasConnectedModel: boolean
  hasWorkspace: boolean
  hasSentMessage: boolean
  onGoSettings: () => void
  onGoExplorer: () => void
  onGoChat: () => void
  onComplete: () => void
}) {
  if (!open) return null

  const allDone = hasConnectedModel && hasWorkspace && hasSentMessage

  return (
    <div className="lex-onboardingOverlay" role="dialog" aria-label="Onboarding">
      <div className="lex-onboardingCard">
        <div className="lex-sectionTitle">Welcome</div>
        <div className="lex-subtle">
          Quick start: connect a model, open a workspace, and send your first prompt.
        </div>

        <div className="lex-onboardingSteps">
          <button className="lex-onboardingStep" onClick={onGoSettings}>
            <span>{hasConnectedModel ? '✓' : '1'}</span>
            <span>Connect a model in Settings</span>
          </button>
          <button className="lex-onboardingStep" onClick={onGoExplorer}>
            <span>{hasWorkspace ? '✓' : '2'}</span>
            <span>Open a project folder in Explorer</span>
          </button>
          <button className="lex-onboardingStep" onClick={onGoChat}>
            <span>{hasSentMessage ? '✓' : '3'}</span>
            <span>Send your first prompt in Chat</span>
          </button>
        </div>

        <div className="lex-field lex-field--row">
          <button className="lex-btn" onClick={onComplete}>
            Skip for now
          </button>
          <button className="lex-btn lex-btn--primary" onClick={onComplete} disabled={!allDone}>
            Finish
          </button>
        </div>
      </div>
    </div>
  )
}
