import { useEffect, useMemo, useRef, useState } from 'react'
import Editor from '@monaco-editor/react'

export function EditorPanel({
  activeFile,
  onChange,
  onSave,
  extractedText,
}: {
  activeFile?: { relPath: string; content: string; isDirty: boolean } | null
  onChange?: (content: string) => void
  onSave?: () => void
  extractedText?: string | null
}) {
  const [value, setValue] = useState('')
  const valueRef = useRef(value)
  valueRef.current = value

  useEffect(() => {
    if (activeFile) {
      setValue(activeFile.content)
      return
    }
    if (!extractedText) return
    setValue((prev) => (prev.trim().length === 0 ? extractedText : prev))
  }, [activeFile?.relPath, activeFile?.content, extractedText])

  const language = useMemo(() => {
    const name = activeFile?.relPath ?? ''
    if (name.endsWith('.py')) return 'python'
    if (name.endsWith('.ts') || name.endsWith('.tsx')) return 'typescript'
    if (name.endsWith('.js') || name.endsWith('.jsx')) return 'javascript'
    if (name.endsWith('.md')) return 'markdown'
    return 'plaintext'
  }, [activeFile?.relPath])

  return (
    <div className="lex-editorPanel">
      <div className="lex-editorHeader">
        <div className="lex-sectionTitle lex-sectionTitle--small">Editor</div>
        <div className="lex-subtle">
          {activeFile ? (
            <>
              {activeFile.relPath} {activeFile.isDirty ? '•' : ''}
            </>
          ) : (
            <>Open a file from Explorer or paste text here.</>
          )}
        </div>
      </div>

      <div className="lex-editorMonaco">
        <Editor
          height="100%"
          defaultLanguage={language}
          language={language}
          theme="vs-dark"
          value={value}
          onChange={(v) => {
            const next = v ?? ''
            setValue(next)
            onChange?.(next)
          }}
          options={{
            minimap: { enabled: false },
            scrollBeyondLastLine: false,
            fontSize: 13,
            wordWrap: 'on',
          }}
          onMount={(editor) => {
            editor.addCommand(editor.getModel() ? 0 : 0, () => {})
            editor.onKeyDown((e) => {
              const isSave = (e.ctrlKey || e.metaKey) && e.keyCode === 49 /* KeyS */
              if (!isSave) return
              e.preventDefault()
              onSave?.()
            })
          }}
        />
      </div>
    </div>
  )
}

